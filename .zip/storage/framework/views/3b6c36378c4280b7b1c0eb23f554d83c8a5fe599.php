<!doctype html>
<!--
* Tabler - Premium and Open Source dashboard template with responsive and high quality UI.
* @version 1.0.0-beta17
* @link https://tabler.io
* Copyright 2018-2023 The Tabler Authors
* Copyright 2018-2023 codecalm.net Paweł Kuna
* Licensed under MIT (https://github.com/tabler/tabler/blob/master/LICENSE)
-->
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Dashboard - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
    <!-- CSS files -->
    <link href="<?php echo e(asset('tabler/dist/css/tabler.min.css?1674944402')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('tabler/dist/css/tabler-flags.min.css?1674944402')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('tabler/dist/css/tabler-payments.min.css?1674944402')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('tabler/dist/css/tabler-vendors.min.css?1674944402')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('tabler/dist/css/demo.min.css?1674944402')); ?>" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <style>
        @import url('https://rsms.me/inter/inter.css');

        :root {
            --tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
        }

        body {
            font-feature-settings: "cv03", "cv04", "cv11";
        }

    </style>
</head>
<body>
    <script src="<?php echo e(asset('tabler/dist/js/demo-theme.min.js?1674944402')); ?>"></script>
    <div class="page">
        <!-- Sidebar -->
        <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Navbar -->
        <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- Libs JS -->
    <script src="<?php echo e(asset('tabler/dist/libs/apexcharts/dist/apexcharts.min.js?1674944402')); ?>" defer></script>
    <script src="<?php echo e(asset('tabler/dist/libs/jsvectormap/dist/js/jsvectormap.min.js?1674944402')); ?>" defer></script>
    <script src="<?php echo e(asset('tabler/dist/libs/jsvectormap/dist/maps/world.js?1674944402')); ?>" defer></script>
    <script src="<?php echo e(asset('tabler/dist/libs/jsvectormap/dist/maps/world-merc.js?1674944402')); ?>" defer></script>

    <!-- Tabler Core -->
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
    <script src="<?php echo e(asset('tabler/dist/js/tabler.min.js?1674944402')); ?>" defer></script>
    <script src="<?php echo e(asset('tabler/dist/js/demo.min.js?1674944402')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/lib/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jquery.mask.min.js')); ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
    <?php echo $__env->yieldPushContent('myscript'); ?>
</body>
</html>
<?php /**PATH C:\Users\nitro 5\Downloads\Compressed\presensigps\presensigps\presensigps\resources\views/layouts/admin/tabler.blade.php ENDPATH**/ ?>