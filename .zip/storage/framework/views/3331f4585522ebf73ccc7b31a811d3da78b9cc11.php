<?php $__env->startSection('header'); ?>
    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">Pilih Jam Kerja</div>
        <div class="right"></div>
    </div>
    <!-- * App Header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="row" style="margin-top:70px">
                <div class="col-12">
                    <?php $__currentLoopData = $jamkerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/presensi/<?php echo e(Crypt::encrypt($d->kode_jam_kerja)); ?>/create"
                            style="text-decoration: none; color:black">
                            <div class="card mb-1" style="border : 1px solid blue">
                                <div class="card-body">
                                    <div class="historicontent">
                                        <div class="iconpresensi">
                                            <ion-icon name="finger-print-outline" style="font-size: 48px;"
                                                class="text-success"></ion-icon>
                                        </div>
                                        <div class="datapresensi">
                                            <h3 style="line-height: 3px"><?php echo e($d->nama_jam_kerja); ?></h3>
                                            <span>Jam Masuk : <?php echo e($d->jam_masuk); ?></span><br>
                                            <span>Jam Pulang : <?php echo e($d->jam_pulang); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.presensi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nitro 5\Downloads\Compressed\presensigps\presensigps\presensigps\resources\views/presensi/pilihjamkerja.blade.php ENDPATH**/ ?>