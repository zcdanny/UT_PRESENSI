<style>
    .historicontent {
        display: flex;
        margin-top: 10px;
    }

    .datapresensi {
        margin-left: 10px;
    }

    .card {
        border: 1px solid blue;
    }
</style>

<?php if($histori->isEmpty()): ?>
    <div class="alert  alert-outline-warning">
        <p>Data Belum Aada</p>
    </div>
<?php endif; ?>
<?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($d->status == 'h'): ?>
        <div class="card mb-1">
            <div class="card-body">
                <div class="historicontent">
                    <div class="iconpresensi">
                        <ion-icon name="finger-print-outline" style="font-size: 48px;" class="text-success"></ion-icon>
                    </div>
                    <div class="datapresensi">
                        <h3 style="line-height: 3px"><?php echo e($d->nama_jam_kerja); ?></h3>
                        <h4 style="margin:0px !important"><?php echo e(date('d-m-Y', strtotime($d->tgl_presensi))); ?></h4>
                        <span>
                            <?php echo $d->jam_in != null ? date('H:i', strtotime($d->jam_in)) : '<span class="text-danger">Belum Scan</span>'; ?>

                        </span>
                        <span>
                            <?php echo $d->jam_out != null
                                ? '-' . date('H:i', strtotime($d->jam_out))
                                : '<span class="text-danger">- Belum Scan</span>'; ?>

                        </span>
                        <br>
                        <?php
                            //Jam Ketika dia Absen
                            $jam_in = date('H:i', strtotime($d->jam_in));

                            //Jam Jadwal Masuk
                            $jam_masuk = date('H:i', strtotime($d->jam_masuk));

                            $jadwal_jam_masuk = $d->tgl_presensi . ' ' . $jam_masuk;
                            $jam_presensi = $d->tgl_presensi . ' ' . $jam_in;
                        ?>
                        <?php if($jam_in > $jam_masuk): ?>
                            <?php
                                $jmlterlambat = hitungjamterlambat($jadwal_jam_masuk, $jam_presensi);
                                $jmlterlambatdesimal = hitungjamterlambatdesimal($jadwal_jam_masuk, $jam_presensi);
                            ?>
                            <span class="danger">Terlambat <?php echo e($jmlterlambat); ?> (<?php echo e($jmlterlambatdesimal); ?> Jam)</span>
                        <?php else: ?>
                            <span style="color:green">Tepat Waktu</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif($d->status == 'i'): ?>
        <div class="card mb-1">
            <div class="card-body">
                <div class="historicontent">
                    <div class="iconpresensi">
                        <ion-icon name="document-outline" style="font-size: 48px;" class="text-warning"></ion-icon>
                    </div>
                    <div class="datapresensi">
                        <h3 style="line-height: 3px">IZIN - <?php echo e($d->kode_izin); ?></h3>
                        <h4 style="margin:0px !important"><?php echo e(date('d-m-Y', strtotime($d->tgl_presensi))); ?></h4>
                        <span>
                            <?php echo e($d->keterangan); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif($d->status == 's'): ?>
        <div class="card mb-1">
            <div class="card-body">
                <div class="historicontent">
                    <div class="iconpresensi">
                        <ion-icon name="medkit-outline" style="font-size: 48px;" class="text-primary"></ion-icon>
                    </div>
                    <div class="datapresensi">
                        <h3 style="line-height: 3px">SAKIT - <?php echo e($d->kode_izin); ?></h3>
                        <h4 style="margin:0px !important"><?php echo e(date('d-m-Y', strtotime($d->tgl_presensi))); ?></h4>
                        <span>
                            <?php echo e($d->keterangan); ?>

                        </span>
                        <br>
                        <?php if(!empty($d->doc_sid)): ?>
                            <span style="color: blue">
                                <ion-icon name="document-attach-outline"></ion-icon> SID
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif($d->status == 'c'): ?>
        <div class="card mb-1">
            <div class="card-body">
                <div class="historicontent">
                    <div class="iconpresensi">
                        <ion-icon name="document-outline" style="font-size: 48px;" class="text-info"></ion-icon>
                    </div>
                    <div class="datapresensi">
                        <h3 style="line-height: 3px">CUTI - <?php echo e($d->kode_izin); ?></h3>
                        <h4 style="margin:0px !important"><?php echo e(date('d-m-Y', strtotime($d->tgl_presensi))); ?></h4>
                        <span class="text-info">
                            <?php echo e($d->nama_cuti); ?>

                        </span>
                        <br>
                        <span>
                            <?php echo e($d->keterangan); ?>

                        </span>

                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\nitro 5\Downloads\Compressed\presensigps\presensigps\presensigps\resources\views/presensi/gethistori.blade.php ENDPATH**/ ?>