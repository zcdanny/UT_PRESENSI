<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Setjamkerjadept extends Model
{
    use HasFactory;
    protected $table = "konfigurasi_jk_dept_detail";
}
